# PolicyHolder.py

from Product import Product
from Payment import Payment
import uuid

class PolicyHolder:
    """Manages policyholder registration, status, and policy details."""
    
    def __init__(self, first_name, last_name, email):
        self.policyholder_id = str(uuid.uuid4())[:8]  # Generate a short unique ID
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.status = "Active"  # Status can be 'Active', 'Suspended', or 'Deceased'
        self.policy_product = None  # Holds a Product object
        self.payment_history = []  # List of Payment objects
        
        # Policyholder automatically registers upon creation (Task: Register)
        print(f"✅ Policyholder registered. ID: {self.policyholder_id}")

    def __str__(self):
        product_name = self.policy_product.name if self.policy_product else "None"
        return (f"Policyholder ID: {self.policyholder_id}\n"
                f"  Name: {self.first_name} {self.last_name} ({self.email})\n"
                f"  Status: {self.status}\n"
                f"  Product: {product_name}\n"
                f"  Last Payment Status: {self.payment_history[-1].__str__() if self.payment_history else 'No payments recorded'}")

    # --- Policyholder Management Methods ---
    
    def suspend_policy(self, reason="Non-Payment"):
        """Suspends the policyholder's account."""
        if self.status == "Active":
            self.status = "Suspended"
            print(f"⚠️ Policy for {self.first_name} suspended. Reason: {reason}.")
            return True
        print(f"Policy for {self.first_name} is already {self.status}.")
        return False

    def reactivate_policy(self):
        """Reactivates a suspended policyholder's account."""
        if self.status == "Suspended":
            self.status = "Active"
            print(f"✅ Policy for {self.first_name} reactivated.")
            return True
        print(f"Policy for {self.first_name} is already {self.status} or cannot be reactivated.")
        return False

    def register_product(self, product):
        """Registers the policyholder to a specific insurance product."""
        if not isinstance(product, Product):
            raise TypeError("Must register a valid Product object.")
        if product.status == "Suspended":
            print(f"❌ Cannot register {self.first_name}. Product {product.name} is currently suspended.")
            return False
            
        self.policy_product = product
        print(f"✅ {self.first_name} registered for product: {product.name}.")
        return True

    def make_payment(self, payment_amount, due_date="N/A"):
        """Creates a new payment instance and processes it."""
        if not self.policy_product:
            print("❌ Cannot make payment: Policyholder has no registered product.")
            return
            
        required_premium = self.policy_product.premium
        new_payment = Payment(required_premium, due_date)
        
        # Process the payment using the Payment class method
        if new_payment.process_payment(payment_amount):
            self.payment_history.append(new_payment)
            
            # If payment was made successfully, ensure policy is 'Active'
            if self.status == "Suspended":
                 self.reactivate_policy()
        else:
            # If payment failed, apply penalty and suspend policy
            new_payment.apply_penalty()
            self.payment_history.append(new_payment)
            self.suspend_policy("Non-Payment/Insufficient Funds")