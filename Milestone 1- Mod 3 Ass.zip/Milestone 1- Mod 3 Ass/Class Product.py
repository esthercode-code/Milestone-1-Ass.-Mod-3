class Product:
    """Manages insurance policy products offered by the company."""
    
    def __init__(self, product_id, name, premium, coverage):
        self.product_id = product_id
        self.name = name
        self.premium = premium  # Monthly or Annual cost
        self.coverage = coverage
        self.status = "Active"  # Status can be 'Active' or 'Suspended'

    def __str__(self):
        return f"ID: {self.product_id}, Name: {self.name}, Premium: ${self.premium:.2f}, Status: {self.status}"

    # Method for creating/updating a product is done via __init__ and update_product
    
    def update_product(self, name=None, premium=None, coverage=None):
        """Updates the details of the policy product."""
        if name:
            self.name = name
        if premium is not None:
            self.premium = premium
        if coverage:
            self.coverage = coverage
        print(f"Product {self.product_id} updated.")

    def suspend_product(self):
        """Removes/suspends a policy product from being offered."""
        self.status = "Suspended"
        print(f"Product {self.product_id} ({self.name}) is now suspended.")

    def reactivate_product(self):
        """Reactivates a suspended policy product."""
        self.status = "Active"
        print(f"Product {self.product_id} ({self.name}) is now active.")
