# Insurance Policy Management System

This project implements a basic policy management system using Python classes to manage Policyholders, Products, and Payments, fulfilling the requirements of the Policy Management System assignment.

## Project Structure

* **`PolicyHolder.py`**: Defines the `PolicyHolder` class, handling registration, suspension, and linking payments/products.
* **`Product.py`**: Defines the `Product` class, managing product creation, updates, and suspension.
* **`Payment.py`**: Defines the `Payment` class, handling payment processing, reminders, and penalties.
* **`main.py`**: The demonstration script that initializes the system, creates products and policyholders, and showcases all required methods.

## Execution Instructions

### Prerequisites

This code requires **Python 3.x**. No external libraries are needed beyond standard Python modules (`uuid`).

### Running the Demonstration

1.  Ensure all four Python files (`PolicyHolder.py`, `Product.py`, `Payment.py`, and `main.py`) are saved in the same directory.
2.  Open your terminal or command prompt.
3.  Navigate to the directory where you saved the files.
4.  Execute the main demonstration script:

    ```bash
    python main.py
    ```

### Expected Output

The script will print a detailed log demonstrating the following functionalities:
* Product creation, update, and suspension.
* Policyholder registration.
* Successful payment and status confirmation (Elena Ramirez).
* Failed payment, penalty application, and policy suspension (Marcus Chen).
* Payment reminder.
* Reactivation through payment (Marcus Chen).
* **Final display of account details for both policyholders.**