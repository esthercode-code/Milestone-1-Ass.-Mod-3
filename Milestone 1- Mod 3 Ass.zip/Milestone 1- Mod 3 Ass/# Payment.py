# Payment.py

class Payment:
    """Manages policy payments, reminders, and penalties."""
    
    def __init__(self, amount, due_date):
        self.amount = amount
        self.due_date = due_date
        self.is_paid = False
        self.penalty_amount = 0.0

    def __str__(self):
        status = "Paid" if self.is_paid else "Pending"
        return f"Amount: ${self.amount:.2f}, Due: {self.due_date}, Status: {status}, Penalty: ${self.penalty_amount:.2f}"

    def process_payment(self, payment_amount):
        """Processes the payment for a policy."""
        if self.is_paid:
            print("Payment already processed for this cycle.")
            return True
        
        required_amount = self.amount + self.penalty_amount
        
        if payment_amount >= required_amount:
            self.is_paid = True
            self.penalty_amount = 0.0  # Clear penalty upon successful payment
            print(f"✅ Payment of ${payment_amount:.2f} processed successfully.")
            if payment_amount > required_amount:
                print(f"Change returned: ${payment_amount - required_amount:.2f}")
            return True
        else:
            print(f"❌ Payment failed. Required: ${required_amount:.2f}. Received: ${payment_amount:.2f}")
            return False

    def send_reminder(self):
        """Simulates sending a payment reminder."""
        if not self.is_paid:
            print(f"🔔 REMINDER: Payment of ${self.amount:.2f} is due by {self.due_date}.")
            return True
        return False

    def apply_penalty(self, penalty_rate=0.05):
        """Applies a penalty if payment is overdue."""
        if not self.is_paid and self.penalty_amount == 0.0:
            penalty = self.amount * penalty_rate
            self.penalty_amount = penalty
            print(f"⚠️ PENALTY: A ${penalty:.2f} penalty has been applied. New total due: ${self.amount + self.penalty_amount:.2f}")
            return True
        return False