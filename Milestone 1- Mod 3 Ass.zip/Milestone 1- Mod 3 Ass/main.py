\# main.py

from Product import Product
from PolicyHolder import PolicyHolder
from Payment import Payment

# --- 1. Product Management Demonstration ---

print("--- Product Management ---")
# Create Policy Products
life_product = Product(101, "Term Life Basic", 50.00, "100k Coverage")
car_product = Product(102, "Standard Auto", 120.50, "Full Liability")
print(life_product)
print(car_product)

# Update and Suspend Product
life_product.update_product(premium=55.00)
car_product.suspend_product()
print("\n--- Products after updates ---")
print(life_product)
print(car_product)
print("-" * 40)

# --- 2. Policyholder Management Demonstration ---

print("--- Policyholder Management ---")
# Create two policyholders (Automatically registers them)
holder1 = PolicyHolder("Elena", "Ramirez", "elena.r@example.com")
holder2 = PolicyHolder("Marcus", "Chen", "marcus.c@example.com")

# Attempt to register for a suspended product (Should fail)
holder1.register_product(car_product) 

# Register Policyholders for an active product
holder1.register_product(life_product)
holder2.register_product(life_product)
print("-" * 40)

# --- 3. Payment and Policy Status Demonstration ---

print("--- Payment and Status Demonstration ---")

# Policyholder 1: Successful Payment
print("\n--- Elena Ramirez Payment (Success) ---")
holder1.make_payment(55.00, "2023-11-25") # Premium is 55.00
print("-" * 40)


# Policyholder 2: Failed Payment (Insufficient funds/Overdue)
print("\n--- Marcus Chen Payment (Failure/Penalty/Suspension) ---")
holder2.make_payment(20.00, "2023-11-25") # Should trigger penalty and suspension

# Demonstrate Payment Reminder
last_payment = holder2.payment_history[-1]
last_payment.send_reminder()
print("-" * 40)

# Reactivation Demonstration (Requires payment)
print("\n--- Marcus Chen Reactivation ---")
# Marcus attempts reactivation by paying the full amount plus the penalty (55.00 + 2.75 = 57.75)
holder2.make_payment(57.75, "2023-12-01")
print("-" * 40)


# --- 4. Policyholder Demonstration (Display Account Details) ---
print("\n######################################")
print("### FINAL POLICYHOLDER ACCOUNT DETAILS ###")
print("######################################")

print("\n--- Elena Ramirez Account Details ---")
# Elena is Active, Paid $55.00
print(holder1)
print(f"Payment History Count: {len(holder1.payment_history)}")


print("\n--- Marcus Chen Account Details ---")
# Marcus is Active, Paid $57.75 (including penalty)
print(holder2)
print(f"Payment History Count: {len(holder2.payment_history)}")

print("\n")